



if not exist %LIBRARY_LIB%\\pkgconfig\\libxrl.pc exit 1
IF %ERRORLEVEL% NEQ 0 exit /B 1
if not exist %LIBRARY_LIB%\\xrl.lib exit 1
IF %ERRORLEVEL% NEQ 0 exit /B 1
if not exist %LIBRARY_INC%\\xraylib\\xraylib.h exit 1
IF %ERRORLEVEL% NEQ 0 exit /B 1
if not exist %LIBRARY_BIN%\\xrl-11.dll exit 1
IF %ERRORLEVEL% NEQ 0 exit /B 1
exit /B 0
