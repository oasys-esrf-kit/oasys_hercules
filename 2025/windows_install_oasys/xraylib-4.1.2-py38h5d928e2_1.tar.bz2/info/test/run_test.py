print("import: 'xraylib'")
import xraylib

print("import: 'xraylib_np'")
import xraylib_np

